﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EqualGate : MonoBehaviour
{

    [SerializeField] float goalNumber;
    [SerializeField] Sprite closedSprite;
    [SerializeField] Sprite openSprite;
    [SerializeField] SpriteRenderer gateSprite;

    bool isOpen = false;

    
    
    enum Condition { EQUAL, GREATER, LESSER};

    [SerializeField]
    Condition goalType;

    public void GoalCheck(float playerCurrentNumber)
    { //This is to check the main goal of a level
        switch (goalType)
        {
            case Condition.EQUAL:
                if (playerCurrentNumber == goalNumber)
                {
                    isOpen = true;
                    gateSprite.sprite = openSprite;
                }
                else
                {
                    isOpen = false;
                    gateSprite.sprite = closedSprite;
                }
                break;
            case Condition.GREATER:
                if(playerCurrentNumber > goalNumber)
                {
                    isOpen = true;
                    gateSprite.sprite = openSprite;
                }
                else
                {
                    isOpen = false;
                    gateSprite.sprite = closedSprite;
                }
                break;
            case Condition.LESSER:
                if(playerCurrentNumber < goalNumber)
                {
                    isOpen = true;
                    gateSprite.sprite = openSprite;
                }
                else
                {
                    isOpen = false;
                    gateSprite.sprite = closedSprite;
                }
                break;
        }
        
    }

    public bool OpenCheck()
    {
        return isOpen;
    }

    public void ObstacleCheck(float playerCurrentNumber)
    { //This is for any obstacles that can open and close
        switch (goalType)
        {
            case Condition.EQUAL:
                if (playerCurrentNumber == goalNumber)
                {
                    gameObject.SetActive(false);
                }
                else
                {
                    gameObject.SetActive(true);
                }
                break;
            case Condition.GREATER:
                if (playerCurrentNumber > goalNumber)
                {
                    gameObject.SetActive(false);
                }
                else
                {
                    gameObject.SetActive(true);
                }
                break;
            case Condition.LESSER:
                if (playerCurrentNumber < goalNumber)
                {
                    gameObject.SetActive(false);
                }
                else
                {
                    gameObject.SetActive(true);
                }
                break;
        }
    }

}
