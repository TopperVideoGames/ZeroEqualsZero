﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NextLevel : MonoBehaviour
{
    [SerializeField]
    bool isLastLevel = false;

    // Update is called once per frame
    void Update()
    {
        LoadNextLevel();
    }

    void LoadNextLevel()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (isLastLevel)
            {
                DataHolder.currentLevel = 0;
                SceneManager.LoadScene(0);
            }
            else
            {
                DataHolder.currentLevel++;
                SceneManager.LoadScene(0);
            }
        }
    }
}
