﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Player : MonoBehaviour
{

    Rigidbody rb;
    float speed = 600f;
    float jumpPower = 25f;

    [SerializeField] EqualGate goalGate;
    [SerializeField] EqualGate[] obstacleGates;

    [SerializeField] GameObject nextLevelObject;
    [SerializeField] GameObject loseZeroMessage;
    [SerializeField] GameObject loseDecimalMessage;

    [SerializeField] BoxCollider singleBox;
    [SerializeField] BoxCollider doubleBox;
    [SerializeField] BoxCollider tripleBox;
    [SerializeField] TextMeshPro playerText;
    [SerializeField] GameObject plusText;
    [SerializeField] GameObject minusText;

    [SerializeField] AudioSource playerAudio;
    [SerializeField] AudioSource playerJumpAudio;
    [SerializeField] AudioClip jumpSFX;
    [SerializeField] AudioClip multiplySFX;
    [SerializeField] AudioClip divideAboveSFX;
    [SerializeField] AudioClip divideBelowSFX;
    [SerializeField] AudioClip plusSignSFX;
    [SerializeField] AudioClip addSFX;
    [SerializeField] AudioClip minusSignSFX;
    [SerializeField] AudioClip subLeftSFX;
    [SerializeField] AudioClip subRightSFX;
    [SerializeField] AudioClip winSFX;
    [SerializeField] AudioClip loseSFX;

    bool hasPlus = false;
    bool hasMinus = false;

    //This is where the gameplay hook comes in.
    float playerNumber = 0;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        TextUpdate();
        goalGate.GoalCheck(playerNumber);
        GoThroughAllObstacles();
        playerJumpAudio.clip = jumpSFX;
    }

    // Update is called once per frame
    void Update()
    {
        Moving();
        Jumping();
        SimulateGravity();
    }

    void SimulateGravity()
    {
        rb.velocity += Vector3.down * 9.8f *6f* Time.deltaTime;
        float downSpeed = rb.velocity.y;
        
        rb.velocity = new Vector3(rb.velocity.x, Mathf.Clamp(downSpeed, -22f, 30f), 0f);
        
    }

    void Moving()
    {
        rb.velocity = new Vector3( Input.GetAxis("Horizontal") * Time.deltaTime * speed, rb.velocity.y,0);
    }

    void Jumping()
    {
        bool groundCheck = false;
        RaycastHit groundRay;
        Physics.Raycast(transform.position, Vector3.down, out groundRay, 1.5f);
        if (groundRay.collider != null)
        {
            if (groundRay.collider.gameObject.tag == "Floor")
                groundCheck = true;
        }
        else
        {
            RaycastHit leftCheck;
            RaycastHit rightCheck;
            Vector3 boundCheck = Vector3.right;
            if (singleBox.enabled)
            {
                boundCheck *= .5f;
            }else if (doubleBox.enabled)
            {
                boundCheck *= 1.768239f;
            }else if (tripleBox.enabled)
            {
                boundCheck *= 2.739454f;
            }
            Physics.Raycast(transform.position + boundCheck, Vector3.down, out rightCheck, 1.5f);
            Physics.Raycast(transform.position - boundCheck, Vector3.down, out leftCheck, 1.5f);
            if(rightCheck.collider != null)
            {
                if (rightCheck.collider.gameObject.tag == "Floor")
                    groundCheck = true;
            }else if(leftCheck.collider != null)
            {
                if (leftCheck.collider.gameObject.tag == "Floor")
                    groundCheck = true;
            }
        }


        if (Input.GetKeyDown(KeyCode.Space) && groundCheck && rb.velocity.y <= 0)
        {
            rb.velocity += Vector3.up * jumpPower;
            playerJumpAudio.Play();
        }
    }

    void TextUpdate()
    {
        playerText.text = playerNumber.ToString();
    }

    void DecimalCheck()
    { //part of the design is to not allow decimal numbers at all, making them a game over condition.
        int numberCheck = (int)playerNumber;
        if(numberCheck != playerNumber)
        {
            
            playerAudio.clip = loseSFX;
            playerAudio.Play();
            loseDecimalMessage.SetActive(true);
            gameObject.SetActive(false);
        }
    }
    void ChangeCollider()
    {
        singleBox.enabled = false;
        doubleBox.enabled = false;
        tripleBox.enabled = false;
        if(playerNumber > 99 || playerNumber < -99)
        {
            tripleBox.enabled = true;
        }else if(playerNumber > 9 || playerNumber < -9)
        {
            doubleBox.enabled = true;
        }
        else
        {
            singleBox.enabled = true;
        }
    }

    
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.GetComponent<Number>() != null)
        {
            //Needs five distinctions for multiply, division above and below, plus and minus.

            Number otherNumber = other.gameObject.GetComponent<Number>();
            if (hasPlus || hasMinus)
            {
                if (hasPlus)
                {
                    playerNumber += otherNumber.getTheNumber();
                    hasPlus = false;
                    plusText.SetActive(false);
                    playerAudio.clip = addSFX;
                    playerAudio.Play();
                }else if (hasMinus)
                {
                    if(transform.position.x >= other.gameObject.transform.position.x)
                    { //player is to the right of other number. Do other - player
                        playerNumber = otherNumber.getTheNumber() - playerNumber;
                        playerAudio.clip = subRightSFX;
                    }
                    else
                    {//player is the left. Do player - other.
                        playerNumber -= otherNumber.getTheNumber();
                        playerAudio.clip = subLeftSFX;
                    }
                    hasMinus = false;
                    minusText.SetActive(false);
                    playerAudio.Play();
                }
            }
            else
            {
                
                float heightDifference = transform.position.y - other.gameObject.transform.position.y;
                Debug.Log(heightDifference);
                if (heightDifference > 1.5f)
                {
                    //its above, do this player number / other number.
                    if (otherNumber.getTheNumber() == 0)
                    {
                       
                        playerAudio.clip = loseSFX;
                        playerAudio.Play();
                        loseZeroMessage.SetActive(true);
                        gameObject.SetActive(false);
                    }
                    else
                    {
                        playerNumber = playerNumber / otherNumber.getTheNumber();
                        playerAudio.clip = divideAboveSFX;
                        playerAudio.Play();
                    }

                }
                else if (heightDifference < -1.5)
                {
                    //Its below, do other number/ player number.
                    if (playerNumber == 0)
                    {
                        
                        playerAudio.clip = loseSFX;
                        playerAudio.Play();
                        loseZeroMessage.SetActive(true);
                        gameObject.SetActive(false);

                    }
                    else
                    {
                        playerNumber = otherNumber.getTheNumber() / playerNumber;
                        playerAudio.clip = divideBelowSFX;
                        playerAudio.Play();
                    }
                }
                else
                {
                    //Multiply
                    playerNumber = playerNumber * otherNumber.getTheNumber();
                    playerAudio.clip = multiplySFX;
                    playerAudio.Play();
                }
            }

            
            TextUpdate();
            Destroy(otherNumber.gameObject);
            DecimalCheck();
            ChangeCollider();
            goalGate.GoalCheck(playerNumber);
            GoThroughAllObstacles();
        }
        if(other.gameObject.tag == "Plus")
        {
            hasPlus = true;
            plusText.SetActive(true);
            Destroy(other.gameObject);
            playerAudio.clip = plusSignSFX;
            playerAudio.Play();
            if (hasMinus)
            {
                hasMinus = false;
                minusText.SetActive(false);
            }
        }else if(other.gameObject.tag == "Minus")
        {
            hasMinus = true;
            minusText.SetActive(true);
            Destroy(other.gameObject);
            playerAudio.clip = minusSignSFX;
            playerAudio.Play();
            if (hasPlus)
            {
                hasPlus = false;
                plusText.SetActive(false);
            }
        }
        if(other.gameObject.GetComponent<EqualGate>() == goalGate)
        {
            if (goalGate.OpenCheck())
            {
                
                playerAudio.clip = winSFX;
                playerAudio.Play();
                nextLevelObject.SetActive(true);
                gameObject.SetActive(false);
            }
        }
    }

    void GoThroughAllObstacles()
    {
        for(int i=0; i < obstacleGates.Length; i++)
        {
            obstacleGates[i].ObstacleCheck(playerNumber);
        }
    }
}
