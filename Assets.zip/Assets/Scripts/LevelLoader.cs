﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelLoader : MonoBehaviour
{

    //This holds a reference to all levels, and loads the correct one based on dataholder.
    
    [SerializeField] GameObject[] levels;

    // Start is called before the first frame update
    void Start()
    {
        Instantiate(levels[DataHolder.currentLevel], transform.position, transform.rotation);
    }

    // Update is called once per frame
    void Update()
    {
        Restart();
    }

    //Can make this object always look for R for reset, always ready.

    void Restart()
    {
        if(Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene(0);
        }
    }

}
