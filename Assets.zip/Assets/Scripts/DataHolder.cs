﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class DataHolder
{
    //This should only worry about current level.
    //Hold current level number, load next level when next is pressed.


    static public int currentLevel = 0;
    
}
